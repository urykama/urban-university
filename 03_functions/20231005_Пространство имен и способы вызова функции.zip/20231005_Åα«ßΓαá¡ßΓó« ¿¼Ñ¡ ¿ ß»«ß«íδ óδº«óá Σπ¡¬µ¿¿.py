def test1():
    a = 1
    b = 2
    print('a =', a, '\t', "b =", b)


def test2(a1, a2, a3):
    print('a1 =', a1, '\t', "a2 =", a2, '\t', "a3 =", a3)


test1()
test2(1, 2, 3)
